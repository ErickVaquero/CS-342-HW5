


public interface UserInterface
{

	public abstract void display(String s);
    public abstract String getLine();

}//end public class UserInterface
